// Product data
const products = [
    {
        id: 1,
        name: "Air Max 2024",
        price: 199.99,
        image: "image/img1.jpg",
        description: "Latest edition of the iconic Air Max series"
    },
    {
        id: 2,
        name: "ZoomX Runner",
        price: 159.99,
        image: "image/img2.jpg",
        description: "Professional running shoes with ZoomX technology"
    },
    {
        id: 3,
        name: "Free Run 5.0",
        price: 129.99,
        image: "image/img3.jpg",
        description: "Lightweight and flexible running experience"
    },
    {
        id: 4,
        name: "React Infinity",
        price: 179.99,
        image: "image/img4.jpg",
        description: "Premium comfort with React foam technology"
    },
    {
        id: 5,
        name: "Pegasus Trail",
        price: 149.99,
        image: "image/img5.jpg",
        description: "All-terrain running shoes for trail adventures"
    },
    {
        id: 6,
        name: "VaporFly Elite",
        price: 249.99,
        image: "image/img6.jpg",
        description: "Elite performance racing shoes"
    }
];

// Cart array
let cart = [];

// Function to render products
function renderProducts() {
    const productGrid = document.getElementById('productGrid');
    productGrid.innerHTML = '';

    products.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        productCard.innerHTML = `
            <img src="${product.image}" alt="${product.name}" class="product-image">
            <div class="product-info">
                <h3 class="product-title">${product.name}</h3>
                <p class="product-description">${product.description}</p>
                <p class="product-price">$${product.price}</p>
                <button onclick="addToCart(${product.id})" class="add-to-cart-btn">Add to Cart</button>
            </div>
        `;
        productGrid.appendChild(productCard);
    });
}

// Function to toggle cart sidebar
function toggleCart() {
    const cartSidebar = document.getElementById('cartSidebar');
    cartSidebar.classList.toggle('open');
}

// Function to add product to cart
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (product) {
        // Check if product already exists in cart
        const existingItem = cart.find(item => item.id === productId);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ ...product, quantity: 1 });
        }
        updateCart();
    }
}

// Function to update cart display
function updateCart() {
    const cartItems = document.getElementById('cartItems');
    const cartCount = document.querySelector('.cart-count');
    const cartTotal = document.getElementById('cartTotal');

    // Update cart count
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;

    // Update cart items
    cartItems.innerHTML = '';
    let total = 0;

    cart.forEach((item, index) => {
        total += item.price * item.quantity;
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <div class="cart-item-details">
                <h4>${item.name}</h4>
                <p>$${item.price} × ${item.quantity}</p>
                <div class="cart-item-controls">
                    <button onclick="updateQuantity(${index}, -1)">-</button>
                    <span>${item.quantity}</span>
                    <button onclick="updateQuantity(${index}, 1)">+</button>
                    <button onclick="removeFromCart(${index})" class="remove-btn">Remove</button>
                </div>
            </div>
        `;
        cartItems.appendChild(cartItem);
    });

    cartTotal.textContent = total.toFixed(2);
}

// Function to update quantity
function updateQuantity(index, change) {
    const item = cart[index];
    const newQuantity = item.quantity + change;
    
    if (newQuantity > 0) {
        item.quantity = newQuantity;
    } else {
        removeFromCart(index);
    }
    updateCart();
}

// Function to remove item from cart
function removeFromCart(index) {
    cart.splice(index, 1);
    updateCart();
}

// Initialize page
window.onload = function() {
    renderProducts();
    updateCart();
};
